import React from 'react';
import "./Recomendation.css"
const Recomendation = () => {
  return (
    <h1 className='recomendation'> recomendação </h1>
  )
}
export default Recomendation;